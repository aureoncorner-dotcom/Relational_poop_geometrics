from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from enum import Enum
from typing import Any, Iterable, Sequence

from .errors import DomainError
from .transition import TransitionRecord
from .z2 import ALL_SECTORS, Axis, Sector, ZERO_SECTOR, sector, z2_add


class LiftabilityStatus(str, Enum):
    PROVED = "PROVED"
    EXHAUSTIVE_FINITE_CHECK = "EXHAUSTIVE_FINITE_CHECK"
    UNRESOLVED = "UNRESOLVED"
    FAILED = "FAILED"

    @property
    def certified(self) -> bool:
        return self in {self.PROVED, self.EXHAUSTIVE_FINITE_CHECK}


@dataclass(frozen=True, slots=True)
class GeneratorReceipt:
    generator_id: str
    increment: Sector
    enabled: bool
    liftability: LiftabilityStatus
    evidence_ref: str | None = None

    def __post_init__(self) -> None:
        if not isinstance(self.generator_id, str) or not self.generator_id.strip():
            raise DomainError("generator_id must be non-empty")
        object.__setattr__(self, "increment", sector(self.increment))
        if self.increment == ZERO_SECTOR:
            raise DomainError("an orbit generator cannot be the zero vector")
        if not isinstance(self.enabled, bool):
            raise DomainError("enabled must be boolean")
        if not isinstance(self.liftability, LiftabilityStatus):
            object.__setattr__(self, "liftability", LiftabilityStatus(self.liftability))

    @classmethod
    def axis(
        cls,
        axis: Axis,
        *,
        enabled: bool = True,
        liftability: LiftabilityStatus = LiftabilityStatus.UNRESOLVED,
        evidence_ref: str | None = None,
    ) -> "GeneratorReceipt":
        return cls(
            generator_id=f"sector_move_{axis.value}",
            increment=axis.basis,
            enabled=enabled,
            liftability=liftability,
            evidence_ref=evidence_ref,
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "generator_id": self.generator_id,
            "increment": list(self.increment),
            "enabled": self.enabled,
            "liftability": self.liftability.value,
            "evidence_ref": self.evidence_ref,
        }


def span(generators: Iterable[Sequence[int]]) -> frozenset[Sector]:
    values = {ZERO_SECTOR}
    for raw in generators:
        generator = sector(raw)
        values |= {z2_add(value, generator) for value in tuple(values)}
    return frozenset(values)


def formal_orbit_report(
    q0: Sequence[int], receipts: Sequence[GeneratorReceipt]
) -> dict[str, Any]:
    origin = sector(q0)
    enabled = [receipt for receipt in receipts if receipt.enabled]
    certified = [receipt for receipt in enabled if receipt.liftability.certified]
    unresolved = [receipt for receipt in enabled if receipt.liftability is LiftabilityStatus.UNRESOLVED]
    failed = [receipt for receipt in enabled if receipt.liftability is LiftabilityStatus.FAILED]
    certified_span = span(receipt.increment for receipt in certified)
    certified_orbit = sorted(z2_add(origin, value) for value in certified_span)
    all_enabled_span = span(receipt.increment for receipt in enabled)

    if failed:
        status = "FAIL"
        reachable_count: int | None = None
    elif unresolved:
        status = "UNRESOLVED"
        reachable_count = None
    else:
        status = "PASS"
        reachable_count = len(certified_orbit)

    return {
        "schema_version": "0.13",
        "status": status,
        "formal_sector_count": len(ALL_SECTORS),
        "q0": list(origin),
        "enabled_sector_generators": [receipt.to_dict() for receipt in enabled],
        "certified_liftable_generators": [receipt.generator_id for receipt in certified],
        "unresolved_liftability_generators": [receipt.generator_id for receipt in unresolved],
        "failed_liftability_generators": [receipt.generator_id for receipt in failed],
        "certified_reachable_lower_bound": len(certified_orbit),
        "certified_reachable_sectors": [list(value) for value in certified_orbit],
        "formal_reachable_sector_count": reachable_count,
        "algebraic_span_if_all_enabled_were_liftable": len(all_enabled_span),
        "claim_boundary": (
            "Formal reachability is reported only for generators with a proved or exhaustive "
            "full-state lift; algebraic availability alone is not compositional reachability."
        ),
    }


def sector_label(value: Sequence[int]) -> str:
    return "".join(str(bit) for bit in sector(value))


def _round_trips(records: Sequence[TransitionRecord]) -> dict[str, int]:
    by_chain: dict[str, list[TransitionRecord]] = defaultdict(list)
    for record in records:
        by_chain[record.chain_id].append(record)
    totals = {axis.value: 0 for axis in Axis}
    for chain_records in by_chain.values():
        for axis in Axis:
            ready_at_zero = chain_records[0].q_before[axis.index] == 0 if chain_records else False
            reached_one = False
            for record in chain_records:
                before = record.q_before[axis.index]
                after = record.q_after[axis.index]
                if not ready_at_zero:
                    if after == 0:
                        ready_at_zero = True
                    continue
                if not reached_one and before == 0 and after == 1:
                    reached_one = True
                elif reached_one and before == 1 and after == 0:
                    totals[axis.value] += 1
                    reached_one = False
    return totals


def observed_accessibility_report(records: Sequence[TransitionRecord]) -> dict[str, Any]:
    labels = [sector_label(value) for value in ALL_SECTORS]
    counts = {source: {target: 0 for target in labels} for source in labels}
    observed: set[Sector] = set()
    chain_last: dict[str, tuple[Sector, str]] = {}

    for record in records:
        prior = chain_last.get(record.chain_id)
        if prior is not None and (
            prior[0] != record.q_before or prior[1] != record.source_state_hash_before
        ):
            raise DomainError(f"non-contiguous transition chain {record.chain_id}")
        chain_last[record.chain_id] = (record.q_after, record.source_state_hash_after)
        observed.update((record.q_before, record.q_after))
        counts[sector_label(record.q_before)][sector_label(record.q_after)] += 1

    denominators = {source: sum(row.values()) for source, row in counts.items()}
    probabilities: dict[str, dict[str, float | None]] = {}
    for source, row in counts.items():
        denominator = denominators[source]
        probabilities[source] = {
            target: (value / denominator if denominator else None)
            for target, value in row.items()
        }

    edges = [
        {"from": source, "to": target, "count": count}
        for source, row in counts.items()
        for target, count in row.items()
        if count and source != target
    ]
    self_transitions = {
        source: row[source] for source, row in counts.items() if row[source]
    }
    round_trips = _round_trips(records)
    return {
        "schema_version": "0.13",
        "formal_sector_count": len(ALL_SECTORS),
        "observed_sector_count": len(observed),
        "observed_sectors": [list(value) for value in sorted(observed)],
        "observed_transition_edges": edges,
        "observed_self_transitions": self_transitions,
        "sector_transition_count_matrix": counts,
        "sector_transition_row_denominators": denominators,
        "sector_transition_matrix": probabilities,
        "completed_round_trips_by_axis": round_trips,
        "effective_round_trips_by_axis": {axis.value: None for axis in Axis},
        "sector_occupancy_ess": None,
        "rank_normalized_rhat": None,
        "mixing_gate_status": "NOT_EVALUATED",
        "claim_boundary": (
            "Rows with no observed departures are null, not zero distributions. The matrix is "
            "descriptive unless a separate strong-lumpability/descent test closes q dynamics."
        ),
    }
