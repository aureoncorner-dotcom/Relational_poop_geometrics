from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any, Mapping

from .errors import DomainError, InvariantError
from .z2 import (
    Axis,
    Sector,
    Winding,
    eta_from_windings,
    sector,
    sector_from_winding,
    winding,
    winding_delta,
    z2_add,
)


class ProposalType(str, Enum):
    CUBE = "cube"
    PLAQUETTE_CURRENT = "plaquette_current"
    CLOSED_MEMBRANE_SHEET = "closed_membrane_sheet"
    EVEN_CURRENT_WORM = "even_current_worm"
    SECTOR_MOVE = "sector_move"


_ZERO_DELTA_TYPES = {
    ProposalType.CUBE,
    ProposalType.PLAQUETTE_CURRENT,
    ProposalType.CLOSED_MEMBRANE_SHEET,
}


def _required_text(value: str, label: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise DomainError(f"{label} must be a non-empty string")
    return value.strip()


def _hash_text(value: str, label: str) -> str:
    text = _required_text(value, label).lower()
    if len(text) != 64 or any(char not in "0123456789abcdef" for char in text):
        raise DomainError(f"{label} must be a lowercase SHA-256 hex digest")
    return text


@dataclass(frozen=True, slots=True)
class TransitionRecord:
    """One complete proposal receipt on the divergence-free Q2 domain."""

    chain_id: str
    sweep: int
    proposal_id: str
    proposal_type: ProposalType
    accepted: bool
    w_before: Winding
    w_after: Winding
    q_before: Sector
    q_after: Sector
    source_state_hash_before: str
    source_state_hash_after: str
    axis: Axis | None = None
    orientation: int | None = None
    divergence_free: bool = True
    protocol_version: str = "0.13"

    def __post_init__(self) -> None:
        object.__setattr__(self, "chain_id", _required_text(self.chain_id, "chain_id"))
        object.__setattr__(self, "proposal_id", _required_text(self.proposal_id, "proposal_id"))
        object.__setattr__(
            self, "protocol_version", _required_text(self.protocol_version, "protocol_version")
        )
        if not isinstance(self.sweep, int) or isinstance(self.sweep, bool) or self.sweep < 0:
            raise DomainError("sweep must be a non-negative integer")
        if not isinstance(self.accepted, bool):
            raise DomainError("accepted must be boolean")
        if not isinstance(self.proposal_type, ProposalType):
            object.__setattr__(self, "proposal_type", ProposalType(self.proposal_type))
        if self.axis is not None and not isinstance(self.axis, Axis):
            object.__setattr__(self, "axis", Axis(self.axis))
        if self.orientation is not None and self.orientation not in (-1, 1):
            raise DomainError("orientation must be -1, +1, or null")
        if self.divergence_free is not True:
            raise DomainError(
                "TransitionRecord uses q=W mod 2 and is restricted to divergence-free h6=0 data"
            )

        object.__setattr__(self, "w_before", winding(self.w_before))
        object.__setattr__(self, "w_after", winding(self.w_after))
        object.__setattr__(self, "q_before", sector(self.q_before))
        object.__setattr__(self, "q_after", sector(self.q_after))
        object.__setattr__(
            self,
            "source_state_hash_before",
            _hash_text(self.source_state_hash_before, "source_state_hash_before"),
        )
        object.__setattr__(
            self,
            "source_state_hash_after",
            _hash_text(self.source_state_hash_after, "source_state_hash_after"),
        )
        self.validate()

    @property
    def delta_w(self) -> Winding:
        return winding_delta(self.w_before, self.w_after)

    @property
    def eta(self) -> Sector:
        return eta_from_windings(
            self.w_before, self.w_after, divergence_free=self.divergence_free
        )

    def validate(self) -> None:
        expected_before = sector_from_winding(self.w_before, divergence_free=True)
        expected_after = sector_from_winding(self.w_after, divergence_free=True)
        if self.q_before != expected_before or self.q_after != expected_after:
            raise InvariantError("q_before/q_after must equal canonical W mod 2")
        if self.q_after != z2_add(self.q_before, self.eta):
            raise InvariantError("sector cocycle invariant q_after=q_before+eta failed")

        delta = tuple(self.delta_w)
        eta = tuple(self.eta)
        if not self.accepted:
            if delta != (0, 0, 0) or eta != (0, 0, 0):
                raise InvariantError("a rejected proposal must leave W and q unchanged")
            if self.source_state_hash_before != self.source_state_hash_after:
                raise InvariantError("a rejected proposal must retain the same accepted-state hash")
            return

        if self.proposal_type in _ZERO_DELTA_TYPES:
            if delta != (0, 0, 0) or eta != (0, 0, 0):
                raise InvariantError(
                    f"accepted {self.proposal_type.value} must leave W and q unchanged"
                )
            return

        if self.proposal_type is ProposalType.EVEN_CURRENT_WORM:
            if any(component % 2 for component in delta) or eta != (0, 0, 0):
                raise InvariantError("accepted even-current worm requires delta_W in 2Z^3")
            return

        if self.proposal_type is ProposalType.SECTOR_MOVE:
            if self.axis is None or self.orientation is None:
                raise InvariantError("accepted sector move requires axis and orientation")
            expected_delta = [0, 0, 0]
            expected_delta[self.axis.index] = self.orientation
            if delta != tuple(expected_delta):
                raise InvariantError("sector move delta_W must be orientation times its axis basis")
            if self.eta != self.axis.basis:
                raise InvariantError("sector move eta must equal the selected axis basis")
            return

        raise InvariantError(f"unsupported proposal type {self.proposal_type}")

    def to_dict(self) -> dict[str, Any]:
        return {
            "protocol_version": self.protocol_version,
            "chain_id": self.chain_id,
            "sweep": self.sweep,
            "proposal_id": self.proposal_id,
            "proposal_type": self.proposal_type.value,
            "axis": None if self.axis is None else self.axis.value,
            "orientation": self.orientation,
            "accepted": self.accepted,
            "divergence_free": self.divergence_free,
            "q_before": list(self.q_before),
            "q_after": list(self.q_after),
            "W_before": list(self.w_before),
            "W_after": list(self.w_after),
            "delta_W": list(self.delta_w),
            "eta": list(self.eta),
            "source_state_hash_before": self.source_state_hash_before,
            "source_state_hash_after": self.source_state_hash_after,
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "TransitionRecord":
        required = {
            "chain_id",
            "sweep",
            "proposal_id",
            "proposal_type",
            "accepted",
            "W_before",
            "W_after",
            "q_before",
            "q_after",
            "source_state_hash_before",
            "source_state_hash_after",
        }
        missing = required - set(value)
        if missing:
            raise DomainError(f"transition record missing fields: {sorted(missing)}")
        record = cls(
            protocol_version=value.get("protocol_version", "0.13"),
            chain_id=value["chain_id"],
            sweep=value["sweep"],
            proposal_id=value["proposal_id"],
            proposal_type=ProposalType(value["proposal_type"]),
            axis=None if value.get("axis") is None else Axis(value["axis"]),
            orientation=value.get("orientation"),
            accepted=value["accepted"],
            divergence_free=value.get("divergence_free", True),
            w_before=winding(value["W_before"]),
            w_after=winding(value["W_after"]),
            q_before=sector(value["q_before"]),
            q_after=sector(value["q_after"]),
            source_state_hash_before=value["source_state_hash_before"],
            source_state_hash_after=value["source_state_hash_after"],
        )
        for derived, actual in (("delta_W", record.delta_w), ("eta", record.eta)):
            if derived in value and tuple(value[derived]) != tuple(actual):
                raise InvariantError(f"serialized {derived} disagrees with source fields")
        return record
