"""Toroidal v0.13 auditable quotient/cocycle reference engine.

The package deliberately separates exact finite algebra, observed diagnostics,
and physical interpretation.  It makes no claim that a platform instantiates
the formal state spaces represented here.
"""

from .z2 import Axis, Sector, Winding, eta_from_windings, sector_from_winding
from .transition import ProposalType, TransitionRecord

__all__ = [
    "Axis",
    "Sector",
    "Winding",
    "ProposalType",
    "TransitionRecord",
    "eta_from_windings",
    "sector_from_winding",
]

__version__ = "0.13.0"

