from __future__ import annotations

import hashlib
import json
import os
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

from .errors import InvariantError, LedgerIntegrityError
from .transition import TransitionRecord
from .z2 import Sector, ZERO_SECTOR, z2_add

GENESIS_HASH = "0" * 64


def stable_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _hashed_envelopes(payloads: Iterable[Mapping[str, Any]]) -> list[dict[str, Any]]:
    previous = GENESIS_HASH
    rows: list[dict[str, Any]] = []
    for sequence, payload in enumerate(payloads):
        body = {
            "sequence": sequence,
            "previous_hash": previous,
            "record": dict(payload),
        }
        record_hash = sha256_bytes(stable_json(body).encode("utf-8"))
        row = {**body, "record_hash": record_hash}
        rows.append(row)
        previous = record_hash
    return rows


def _atomic_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temp_name = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    temp_path = Path(temp_name)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8", newline="\n") as handle:
            handle.write(text)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp_path, path)
    except Exception:
        temp_path.unlink(missing_ok=True)
        raise


def write_json(value: Mapping[str, Any], path: Path) -> dict[str, Any]:
    _atomic_text(path, json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + "\n")
    return {"path": path.name, "file_sha256": sha256_file(path)}


def write_text(text: str, path: Path) -> dict[str, Any]:
    _atomic_text(path, text)
    return {"path": path.name, "file_sha256": sha256_file(path)}


def write_payload_ledger(payloads: Iterable[Mapping[str, Any]], path: Path) -> dict[str, Any]:
    rows = _hashed_envelopes(payloads)
    text = "".join(stable_json(row) + "\n" for row in rows)
    _atomic_text(path, text)
    return {
        "path": path.name,
        "rows": len(rows),
        "last_entry_hash": rows[-1]["record_hash"] if rows else GENESIS_HASH,
        "file_sha256": sha256_file(path),
    }


def write_transition_ledger(
    records: Iterable[TransitionRecord], path: Path
) -> dict[str, Any]:
    return write_payload_ledger((record.to_dict() for record in records), path)


def _validated_rows(path: Path) -> list[dict[str, Any]]:
    previous = GENESIS_HASH
    rows: list[dict[str, Any]] = []
    try:
        lines = path.read_text(encoding="utf-8").splitlines()
    except (OSError, UnicodeError) as error:
        raise LedgerIntegrityError(f"cannot read ledger {path}: {error}") from error
    for sequence, line in enumerate(lines):
        if not line.strip():
            raise LedgerIntegrityError(f"blank ledger line at {sequence + 1}")
        try:
            row = json.loads(line)
        except json.JSONDecodeError as error:
            raise LedgerIntegrityError(f"invalid JSON at ledger line {sequence + 1}") from error
        if not isinstance(row, dict) or set(row) != {
            "sequence",
            "previous_hash",
            "record",
            "record_hash",
        }:
            raise LedgerIntegrityError(f"malformed envelope at ledger line {sequence + 1}")
        if row["sequence"] != sequence:
            raise LedgerIntegrityError(f"non-contiguous sequence at ledger line {sequence + 1}")
        if row["previous_hash"] != previous:
            raise LedgerIntegrityError(f"broken previous hash at ledger line {sequence + 1}")
        body = {
            "sequence": row["sequence"],
            "previous_hash": row["previous_hash"],
            "record": row["record"],
        }
        expected = sha256_bytes(stable_json(body).encode("utf-8"))
        if row["record_hash"] != expected:
            raise LedgerIntegrityError(f"record hash mismatch at ledger line {sequence + 1}")
        rows.append(row)
        previous = expected
    return rows


def verify_payload_ledger(path: Path) -> dict[str, Any]:
    rows = _validated_rows(path)
    return {
        "ok": True,
        "rows": len(rows),
        "last_entry_hash": rows[-1]["record_hash"] if rows else GENESIS_HASH,
        "file_sha256": sha256_file(path),
    }


def read_payload_ledger(path: Path) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    rows = _validated_rows(path)
    payloads: list[dict[str, Any]] = []
    for index, row in enumerate(rows):
        if not isinstance(row["record"], dict):
            raise LedgerIntegrityError(f"ledger payload at line {index + 1} is not an object")
        payloads.append(row["record"])
    return payloads, {
        "ok": True,
        "rows": len(rows),
        "last_entry_hash": rows[-1]["record_hash"] if rows else GENESIS_HASH,
        "file_sha256": sha256_file(path),
    }


def read_transition_ledger(path: Path) -> tuple[list[TransitionRecord], dict[str, Any]]:
    rows = _validated_rows(path)
    records: list[TransitionRecord] = []
    for index, row in enumerate(rows):
        try:
            records.append(TransitionRecord.from_dict(row["record"]))
        except Exception as error:
            raise LedgerIntegrityError(f"invalid transition at ledger line {index + 1}: {error}") from error
    report = {
        "ok": True,
        "rows": len(rows),
        "last_entry_hash": rows[-1]["record_hash"] if rows else GENESIS_HASH,
        "file_sha256": sha256_file(path),
    }
    return records, report


@dataclass(frozen=True, slots=True)
class CocycleReceipt:
    source_sequence: int
    source_record_hash: str
    chain_id: str
    chain_transition_index: int
    proposal_id: str
    q_origin: Sector
    q_before: Sector
    q_after: Sector
    eta: Sector
    cumulative_cocycle: Sector

    def to_dict(self) -> dict[str, Any]:
        return {
            "source_sequence": self.source_sequence,
            "source_record_hash": self.source_record_hash,
            "chain_id": self.chain_id,
            "chain_transition_index": self.chain_transition_index,
            "proposal_id": self.proposal_id,
            "q_origin": list(self.q_origin),
            "q_before": list(self.q_before),
            "q_after": list(self.q_after),
            "eta": list(self.eta),
            "cumulative_cocycle": list(self.cumulative_cocycle),
        }


def derive_cocycle_receipts(
    records: Sequence[TransitionRecord], source_hashes: Sequence[str] | None = None
) -> list[CocycleReceipt]:
    if source_hashes is not None and len(source_hashes) != len(records):
        raise InvariantError("source_hashes length must match transition records")
    state: dict[str, dict[str, Any]] = {}
    receipts: list[CocycleReceipt] = []
    for sequence, record in enumerate(records):
        chain = state.get(record.chain_id)
        if chain is None:
            chain = {
                "origin": record.q_before,
                "last_q": record.q_before,
                "last_state_hash": record.source_state_hash_before,
                "cumulative": ZERO_SECTOR,
                "index": 0,
            }
            state[record.chain_id] = chain
        if chain["last_q"] != record.q_before:
            raise InvariantError(
                f"non-contiguous q state in chain {record.chain_id} at {record.proposal_id}"
            )
        if chain["last_state_hash"] != record.source_state_hash_before:
            raise InvariantError(
                f"non-contiguous source state hash in chain {record.chain_id} at {record.proposal_id}"
            )
        cumulative = z2_add(chain["cumulative"], record.eta)
        if record.q_after != z2_add(chain["origin"], cumulative):
            raise InvariantError("accumulated sector cocycle failed to telescope")
        source_hash = (
            source_hashes[sequence]
            if source_hashes is not None
            else sha256_bytes(stable_json(record.to_dict()).encode("utf-8"))
        )
        receipts.append(
            CocycleReceipt(
                source_sequence=sequence,
                source_record_hash=source_hash,
                chain_id=record.chain_id,
                chain_transition_index=chain["index"],
                proposal_id=record.proposal_id,
                q_origin=chain["origin"],
                q_before=record.q_before,
                q_after=record.q_after,
                eta=record.eta,
                cumulative_cocycle=cumulative,
            )
        )
        chain["last_q"] = record.q_after
        chain["last_state_hash"] = record.source_state_hash_after
        chain["cumulative"] = cumulative
        chain["index"] += 1
    return receipts


def transition_envelope_hashes(path: Path) -> list[str]:
    return [row["record_hash"] for row in _validated_rows(path)]
