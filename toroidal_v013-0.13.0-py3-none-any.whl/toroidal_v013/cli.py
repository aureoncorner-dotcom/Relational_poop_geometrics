from __future__ import annotations

import argparse
import json
import sys
import tempfile
from pathlib import Path
from typing import Sequence

from . import __version__
from .descent import strong_lumpability_report
from .diamond import diamond_report, sheet_bit
from .engine import (
    demo_generators,
    demo_records,
    verify_analysis_bundle,
    write_analysis_bundle,
)
from .errors import ToroidalError, UndefinedQuotientError
from .flux import ThroatProfile, spatial_flux_report
from .ledger import read_transition_ledger, verify_payload_ledger
from .orbit import GeneratorReceipt, LiftabilityStatus
from .two_clock import TwoClockConfig
from .z2 import Axis


def _json(value: object) -> None:
    print(json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2))


def _command_demo(args: argparse.Namespace) -> None:
    manifest = write_analysis_bundle(
        demo_records(), demo_generators(), Path(args.output).resolve()
    )
    verification = verify_analysis_bundle(Path(args.output).resolve())
    _json({"manifest": manifest, "verification": verification})


def _command_analyze(args: argparse.Namespace) -> None:
    records, source_verification = read_transition_ledger(Path(args.ledger).resolve())
    status = LiftabilityStatus(args.liftability)
    generators = [
        GeneratorReceipt.axis(
            Axis(value), liftability=status, evidence_ref=args.liftability_evidence
        )
        for value in args.generator
    ]
    manifest = write_analysis_bundle(records, generators, Path(args.output).resolve())
    _json({"source_ledger": source_verification, "manifest": manifest})


def _command_verify_ledger(args: argparse.Namespace) -> None:
    _json(verify_payload_ledger(Path(args.ledger).resolve()))


def _command_verify_bundle(args: argparse.Namespace) -> None:
    _json(verify_analysis_bundle(Path(args.bundle).resolve()))


def _command_diamond(args: argparse.Namespace) -> None:
    report = diamond_report(args.length)
    if args.x is not None and args.y is not None:
        try:
            report["sheet_bit"] = sheet_bit(args.length, args.x, args.y)
        except UndefinedQuotientError as error:
            report["sheet_bit"] = None
            report["sheet_bit_error"] = str(error)
    _json(report)


def _two_clock(args: argparse.Namespace) -> TwoClockConfig:
    return TwoClockConfig(
        theta0=args.theta0,
        lattice_period=args.period,
        g0=args.g0,
        lattice_order=args.order,
        catch_width=args.width,
        timestamp_units=args.timestamp_units,
        time_origin=args.time_origin,
        boundary_tolerance=args.boundary_tolerance,
    )


def _command_two_clock(args: argparse.Namespace) -> None:
    config = _two_clock(args)
    result = config.classify(args.index, args.timestamp, eligible=args.eligible)
    _json(
        {
            "classification": result,
            "unlabelled_period_check": config.verify_unlabelled_period(
                args.index, args.timestamp
            ),
            "spec": config.to_spec(),
        }
    )


def _command_flux(args: argparse.Namespace) -> None:
    profile = ThroatProfile(
        length_steps=args.length,
        u0=args.u0,
        epsilon=args.epsilon,
        s0=args.s0,
        material_radius0=args.material_radius,
        eulerian_radius=args.eulerian_radius,
    )
    _json(spatial_flux_report(profile, tolerance=args.tolerance))


def _command_self_test(_: argparse.Namespace) -> None:
    with tempfile.TemporaryDirectory(prefix="toroidal-v013-") as temp:
        bundle = Path(temp) / "bundle"
        write_analysis_bundle(demo_records(), demo_generators(), bundle)
        verification = verify_analysis_bundle(bundle)
    odd_l_rejected = False
    try:
        sheet_bit(3, 0, 0)
    except UndefinedQuotientError:
        odd_l_rejected = True
    clock = TwoClockConfig(
        theta0=0.125,
        lattice_period=12.0,
        g0=0.25,
        lattice_order=3,
        catch_width=0.05,
        timestamp_units="seconds since frozen epoch",
    )
    flux = spatial_flux_report(
        ThroatProfile(
            length_steps=12,
            u0=2.0,
            epsilon=0.2,
            s0=3.0,
            material_radius0=1.0,
            eulerian_radius=0.5,
        )
    )
    lumpability = strong_lumpability_report(
        {
            "a0": {"a0": 0.5, "b0": 0.5},
            "a1": {"a1": 0.5, "b1": 0.5},
            "b0": {"a0": 0.25, "b0": 0.75},
            "b1": {"a1": 0.25, "b1": 0.75},
        },
        {"a0": "a", "a1": "a", "b0": "b", "b1": "b"},
    )
    checks = {
        "analysis_bundle": verification["ok"],
        "odd_L_sheet_bit_rejected": odd_l_rejected,
        "unlabelled_period": clock.verify_unlabelled_period(7, 2.5),
        "material_zero_cocycle": flux["material"]["checks_passed"],
        "periodic_flux_closure": flux["eulerian"]["periodic_flux_closure"],
        "strong_lumpability_fixture": lumpability["strong_lumpability"] == "PASSED",
    }
    _json({"ok": all(checks.values()), "checks": checks})
    if not all(checks.values()):
        raise ToroidalError("internal self-test failed")


def make_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="toroidal-v013",
        description="Auditable orbit-quotient and residual-cocycle reference engine",
    )
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    commands = parser.add_subparsers(dest="command", required=True)

    demo = commands.add_parser("demo", help="write and verify a deterministic eight-sector bundle")
    demo.add_argument("--output", required=True)
    demo.set_defaults(func=_command_demo)

    analyze = commands.add_parser("analyze", help="derive reports from a transition ledger")
    analyze.add_argument("ledger")
    analyze.add_argument("--output", required=True)
    analyze.add_argument(
        "--generator", action="append", choices=[axis.value for axis in Axis], default=[]
    )
    analyze.add_argument(
        "--liftability",
        choices=[value.value for value in LiftabilityStatus],
        default=LiftabilityStatus.UNRESOLVED.value,
    )
    analyze.add_argument("--liftability-evidence")
    analyze.set_defaults(func=_command_analyze)

    verify_ledger = commands.add_parser("verify-ledger", help="verify a hash-chained JSONL ledger")
    verify_ledger.add_argument("ledger")
    verify_ledger.set_defaults(func=_command_verify_ledger)

    verify_bundle = commands.add_parser("verify-bundle", help="verify a complete analysis bundle")
    verify_bundle.add_argument("bundle")
    verify_bundle.set_defaults(func=_command_verify_bundle)

    diamond = commands.add_parser("diamond", help="inspect the corrected diagonal-torus quotient")
    diamond.add_argument("--length", type=int, required=True)
    diamond.add_argument("--x", type=int)
    diamond.add_argument("--y", type=int)
    diamond.set_defaults(func=_command_diamond)

    clock = commands.add_parser("two-clock", help="classify one prospective two-clock opportunity")
    clock.add_argument("--theta0", type=float, required=True)
    clock.add_argument("--period", type=float, required=True)
    clock.add_argument("--g0", type=float, required=True)
    clock.add_argument("--order", type=int, required=True)
    clock.add_argument("--width", type=float, required=True)
    clock.add_argument("--timestamp-units", required=True)
    clock.add_argument("--time-origin", type=float, default=0.0)
    clock.add_argument("--boundary-tolerance", type=float, default=1e-12)
    clock.add_argument("--index", type=int, required=True)
    clock.add_argument("--timestamp", type=float, required=True)
    eligibility = clock.add_mutually_exclusive_group(required=True)
    eligibility.add_argument("--eligible", dest="eligible", action="store_true")
    eligibility.add_argument("--ineligible", dest="eligible", action="store_false")
    eligibility.add_argument("--eligibility-unknown", dest="eligible", action="store_const", const=None)
    clock.set_defaults(func=_command_two_clock)

    flux = commands.add_parser("flux", help="emit a typed material/Eulerian spatial-cocycle report")
    flux.add_argument("--length", type=int, required=True)
    flux.add_argument("--u0", type=float, required=True)
    flux.add_argument("--epsilon", type=float, required=True)
    flux.add_argument("--s0", type=float, required=True)
    flux.add_argument("--material-radius", type=float, required=True)
    flux.add_argument("--eulerian-radius", type=float, required=True)
    flux.add_argument("--tolerance", type=float, default=1e-12)
    flux.set_defaults(func=_command_flux)

    self_test = commands.add_parser("self-test", help="run dependency-free internal checks")
    self_test.set_defaults(func=_command_self_test)
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    parser = make_parser()
    args = parser.parse_args(argv)
    try:
        args.func(args)
    except (ToroidalError, OSError, ValueError) as error:
        print(f"ERROR: {error}", file=sys.stderr)
        return 2
    return 0
