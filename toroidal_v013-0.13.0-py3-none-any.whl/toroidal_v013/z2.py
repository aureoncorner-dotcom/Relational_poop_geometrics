from __future__ import annotations

from enum import Enum
from fractions import Fraction
from itertools import product
from numbers import Number
from typing import Iterable, Mapping, NewType, Sequence, TypeAlias, TypeVar

from .errors import DomainError

Winding = NewType("Winding", tuple[int, int, int])
Sector = NewType("Sector", tuple[int, int, int])
Vector3: TypeAlias = tuple[int, int, int]
TNumber = TypeVar("TNumber", bound=Number)


class Axis(str, Enum):
    X = "x"
    Y = "y"
    Z = "z"

    @property
    def index(self) -> int:
        return {Axis.X: 0, Axis.Y: 1, Axis.Z: 2}[self]

    @property
    def basis(self) -> Sector:
        values = [0, 0, 0]
        values[self.index] = 1
        return Sector(tuple(values))


ALL_SECTORS: tuple[Sector, ...] = tuple(
    Sector(tuple(bits)) for bits in product((0, 1), repeat=3)
)
ZERO_SECTOR = Sector((0, 0, 0))


def _integer_triple(value: Sequence[int] | Iterable[int], label: str) -> Vector3:
    values = tuple(value)
    if len(values) != 3:
        raise DomainError(f"{label} must contain exactly three coordinates")
    if any(not isinstance(item, int) or isinstance(item, bool) for item in values):
        raise DomainError(f"{label} coordinates must be integers, not booleans")
    return values  # type: ignore[return-value]


def winding(value: Sequence[int] | Iterable[int]) -> Winding:
    return Winding(_integer_triple(value, "winding"))


def sector(value: Sequence[int] | Iterable[int]) -> Sector:
    values = _integer_triple(value, "sector")
    if any(item not in (0, 1) for item in values):
        raise DomainError("sector coordinates must use canonical residues 0 or 1")
    return Sector(values)


def canonical_mod2(value: int) -> int:
    if not isinstance(value, int) or isinstance(value, bool):
        raise DomainError("mod-two input must be an integer")
    return value % 2


def mod2_vector(value: Sequence[int] | Iterable[int]) -> Sector:
    return Sector(tuple(canonical_mod2(item) for item in _integer_triple(value, "vector")))


def sector_from_winding(
    value: Sequence[int] | Iterable[int], *, divergence_free: bool
) -> Sector:
    """Return q=W mod 2 only on the divergence-free integer-winding domain.

    At finite charge-six endpoint density, W need not be integral.  Callers on
    that broader domain must use a separately defined cut-parity observable.
    """

    if divergence_free is not True:
        raise DomainError(
            "q=W mod 2 is defined here only for divergence-free integer current (h6=0)"
        )
    return mod2_vector(_integer_triple(value, "winding"))


def winding_delta(before: Sequence[int], after: Sequence[int]) -> Winding:
    left = _integer_triple(before, "W_before")
    right = _integer_triple(after, "W_after")
    return Winding(tuple(b - a for a, b in zip(left, right)))


def eta_from_windings(
    before: Sequence[int], after: Sequence[int], *, divergence_free: bool
) -> Sector:
    if divergence_free is not True:
        raise DomainError("winding-derived eta requires the divergence-free h6=0 domain")
    return mod2_vector(winding_delta(before, after))


def z2_add(left: Sequence[int], right: Sequence[int]) -> Sector:
    a = sector(left)
    b = sector(right)
    return Sector(tuple((x + y) % 2 for x, y in zip(a, b)))


def z2_sum(values: Iterable[Sequence[int]]) -> Sector:
    total = ZERO_SECTOR
    for value in values:
        total = z2_add(total, value)
    return total


def dot_mod2(left: Sequence[int], right: Sequence[int]) -> int:
    a = sector(left)
    b = sector(right)
    return sum(x * y for x, y in zip(a, b)) % 2


def character(label: Sequence[int], state: Sequence[int]) -> int:
    return -1 if dot_mod2(label, state) else 1


def _complete_sector_map(values: Mapping[Sequence[int], TNumber], label: str) -> dict[Sector, TNumber]:
    normalized = {sector(key): value for key, value in values.items()}
    missing = set(ALL_SECTORS) - set(normalized)
    extra = set(normalized) - set(ALL_SECTORS)
    if missing or extra:
        raise DomainError(f"{label} must contain each of the eight sectors exactly once")
    return normalized


def direct_from_dual(dual: Mapping[Sequence[int], TNumber]) -> dict[Sector, TNumber]:
    """Compute Z_h = sum_q (-1)^(h·q) mathcal_Z_q."""

    source = _complete_sector_map(dual, "dual sector map")
    return {
        h: sum(character(h, q) * source[q] for q in ALL_SECTORS)  # type: ignore[misc]
        for h in ALL_SECTORS
    }


def dual_from_direct(direct: Mapping[Sequence[int], TNumber]) -> dict[Sector, TNumber | Fraction]:
    """Compute mathcal_Z_q = (1/8) sum_h (-1)^(h·q) Z_h."""

    source = _complete_sector_map(direct, "direct sector map")
    result: dict[Sector, TNumber | Fraction] = {}
    for q in ALL_SECTORS:
        total = sum(character(h, q) * source[h] for h in ALL_SECTORS)  # type: ignore[misc]
        result[q] = total / 8  # type: ignore[assignment,operator]
    return result


def odd_fraction_from_partition_ratio(ratio: float) -> float:
    if not isinstance(ratio, (int, float)) or isinstance(ratio, bool):
        raise DomainError("partition ratio must be numeric")
    if not -1.0 <= float(ratio) <= 1.0:
        raise DomainError("character partition ratio must lie in [-1, 1]")
    return 0.5 * (1.0 - float(ratio))
