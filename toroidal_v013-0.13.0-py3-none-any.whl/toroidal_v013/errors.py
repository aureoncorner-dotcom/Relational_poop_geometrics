class ToroidalError(Exception):
    """Base class for domain and validation failures."""


class DomainError(ToroidalError, ValueError):
    """Raised when an exact construction is used outside its declared domain."""


class InvariantError(ToroidalError, ValueError):
    """Raised when a transition violates an exact invariant."""


class LedgerIntegrityError(ToroidalError, ValueError):
    """Raised when a ledger is malformed or its hash chain does not verify."""


class UndefinedQuotientError(DomainError):
    """Raised when a proposed quotient does not descend to the stated space."""

