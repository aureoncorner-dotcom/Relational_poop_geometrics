from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Sequence

from .descent import not_claimed_projection_report
from .errors import LedgerIntegrityError
from .ledger import (
    derive_cocycle_receipts,
    read_payload_ledger,
    read_transition_ledger,
    sha256_bytes,
    sha256_file,
    stable_json,
    transition_envelope_hashes,
    verify_payload_ledger,
    write_json,
    write_payload_ledger,
    write_text,
    write_transition_ledger,
)
from .orbit import (
    GeneratorReceipt,
    LiftabilityStatus,
    observed_accessibility_report,
    formal_orbit_report,
)
from .transition import ProposalType, TransitionRecord
from .z2 import Axis, Winding, sector_from_winding


ARTIFACT_NAMES = (
    "sector_transition_operator_ledger.jsonl",
    "sector_cocycle_ledger.jsonl",
    "formal_orbit_report.json",
    "observed_accessibility_report.json",
    "q_projection_lumpability_or_descent_report.json",
    "closure_counterexamples.jsonl",
)


def write_analysis_bundle(
    records: Sequence[TransitionRecord],
    generators: Sequence[GeneratorReceipt],
    output_dir: Path,
    *,
    projection_report: dict[str, Any] | None = None,
) -> dict[str, Any]:
    output_dir.mkdir(parents=True, exist_ok=True)
    transition_path = output_dir / ARTIFACT_NAMES[0]
    transition_info = write_transition_ledger(records, transition_path)
    envelope_hashes = transition_envelope_hashes(transition_path)
    cocycle_receipts = derive_cocycle_receipts(records, envelope_hashes)
    cocycle_info = write_payload_ledger(
        (receipt.to_dict() for receipt in cocycle_receipts), output_dir / ARTIFACT_NAMES[1]
    )

    origin = records[0].q_before if records else (0, 0, 0)
    formal = formal_orbit_report(origin, generators)
    observed = observed_accessibility_report(records)
    projection = projection_report or not_claimed_projection_report()
    counterexamples = projection.get("counterexamples", [])
    if not isinstance(counterexamples, list):
        raise ValueError("projection report counterexamples must be a list")

    write_json(formal, output_dir / ARTIFACT_NAMES[2])
    write_json(observed, output_dir / ARTIFACT_NAMES[3])
    write_json(projection, output_dir / ARTIFACT_NAMES[4])
    counterexample_info = write_payload_ledger(
        counterexamples, output_dir / ARTIFACT_NAMES[5]
    )

    entries = [
        {
            "path": name,
            "bytes": (output_dir / name).stat().st_size,
            "sha256": sha256_file(output_dir / name),
        }
        for name in sorted(ARTIFACT_NAMES)
    ]
    manifest = {
        "schema_version": "0.13",
        "artifact_type": "TOROIDAL_ORBIT_COCYCLE_ANALYSIS_BUNDLE",
        "files": entries,
        "transition_rows": len(records),
        "cocycle_rows": len(cocycle_receipts),
        "transition_last_entry_hash": transition_info["last_entry_hash"],
        "cocycle_last_entry_hash": cocycle_info["last_entry_hash"],
        "counterexample_last_entry_hash": counterexample_info["last_entry_hash"],
        "hash_scope": "Hashes bind exact artifact bytes and lineage; they do not validate interpretation.",
    }
    write_json(manifest, output_dir / "MANIFEST.json")
    sums = "".join(f"{entry['sha256']}  {entry['path']}\n" for entry in entries)
    write_text(sums, output_dir / "SHA256SUMS")
    return manifest


def verify_analysis_bundle(output_dir: Path) -> dict[str, Any]:
    manifest_path = output_dir / "MANIFEST.json"
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as error:
        raise LedgerIntegrityError(f"cannot parse bundle manifest: {error}") from error
    expected_names = set(ARTIFACT_NAMES)
    entries = manifest.get("files")
    if not isinstance(entries, list) or {entry.get("path") for entry in entries} != expected_names:
        raise LedgerIntegrityError("manifest does not cover the exact required artifact set")
    verified: list[dict[str, Any]] = []
    for entry in entries:
        path = output_dir / entry["path"]
        if not path.is_file():
            raise LedgerIntegrityError(f"missing artifact {entry['path']}")
        if path.stat().st_size != entry["bytes"] or sha256_file(path) != entry["sha256"]:
            raise LedgerIntegrityError(f"artifact digest mismatch for {entry['path']}")
        verified.append(entry)
    sums_path = output_dir / "SHA256SUMS"
    try:
        sums_lines = sums_path.read_text(encoding="utf-8").splitlines()
    except (OSError, UnicodeError) as error:
        raise LedgerIntegrityError(f"cannot read SHA256SUMS: {error}") from error
    expected_sum_lines = [f"{entry['sha256']}  {entry['path']}" for entry in entries]
    if sums_lines != expected_sum_lines:
        raise LedgerIntegrityError("SHA256SUMS does not exactly match the manifest")

    records, transition_report = read_transition_ledger(output_dir / ARTIFACT_NAMES[0])
    transition_hashes = transition_envelope_hashes(output_dir / ARTIFACT_NAMES[0])
    cocycle_payloads, cocycle_report = read_payload_ledger(output_dir / ARTIFACT_NAMES[1])
    expected_cocycle = [
        receipt.to_dict() for receipt in derive_cocycle_receipts(records, transition_hashes)
    ]
    if cocycle_payloads != expected_cocycle:
        raise LedgerIntegrityError("cocycle ledger does not derive from the transition ledger")

    try:
        formal = json.loads((output_dir / ARTIFACT_NAMES[2]).read_text(encoding="utf-8"))
        observed = json.loads((output_dir / ARTIFACT_NAMES[3]).read_text(encoding="utf-8"))
        projection = json.loads((output_dir / ARTIFACT_NAMES[4]).read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as error:
        raise LedgerIntegrityError(f"cannot parse analysis report: {error}") from error
    generator_rows = formal.get("enabled_sector_generators")
    if not isinstance(generator_rows, list):
        raise LedgerIntegrityError("formal orbit report lacks generator receipts")
    try:
        generators = [
            GeneratorReceipt(
                generator_id=row["generator_id"],
                increment=tuple(row["increment"]),
                enabled=row["enabled"],
                liftability=LiftabilityStatus(row["liftability"]),
                evidence_ref=row.get("evidence_ref"),
            )
            for row in generator_rows
        ]
        expected_formal = formal_orbit_report(formal["q0"], generators)
    except Exception as error:
        raise LedgerIntegrityError(f"invalid formal-orbit report: {error}") from error
    if formal != expected_formal:
        raise LedgerIntegrityError("formal-orbit report does not derive from its receipts")
    if observed != observed_accessibility_report(records):
        raise LedgerIntegrityError("observed-accessibility report does not derive from transitions")

    counterexample_payloads, counterexample_report = read_payload_ledger(
        output_dir / ARTIFACT_NAMES[5]
    )
    if not isinstance(projection.get("counterexamples"), list):
        raise LedgerIntegrityError("projection report counterexamples must be a list")
    if counterexample_payloads != projection["counterexamples"]:
        raise LedgerIntegrityError("counterexample ledger does not match the projection report")
    if manifest.get("transition_rows") != len(records) or manifest.get("cocycle_rows") != len(
        cocycle_payloads
    ):
        raise LedgerIntegrityError("manifest row counts do not match ledgers")
    return {
        "ok": True,
        "verified_files": len(verified),
        "transition_ledger": transition_report,
        "cocycle_ledger": cocycle_report,
        "counterexample_ledger": counterexample_report,
        "semantic_derivation_checks": {
            "cocycle_from_transitions": "PASS",
            "formal_orbit_from_generator_receipts": "PASS",
            "observed_accessibility_from_transitions": "PASS",
            "counterexamples_match_projection_report": "PASS",
            "sha256sums_matches_manifest": "PASS",
        },
        "manifest_sha256": sha256_file(manifest_path),
    }


def _demo_state_hash(chain_id: str, sequence: int, value: Winding) -> str:
    return sha256_bytes(
        stable_json(
            {
                "fixture": "formal_demo_not_physical_data",
                "chain_id": chain_id,
                "sequence": sequence,
                "W": list(value),
            }
        ).encode("utf-8")
    )


def demo_records() -> list[TransitionRecord]:
    """Deterministic fixture visiting all eight q sectors via a Gray-code loop."""

    chain_id = "demo-chain-000"
    current = Winding((0, 0, 0))
    current_hash = _demo_state_hash(chain_id, 0, current)
    records: list[TransitionRecord] = []

    def append(
        proposal_type: ProposalType,
        delta: tuple[int, int, int],
        *,
        axis: Axis | None = None,
        orientation: int | None = None,
        accepted: bool = True,
    ) -> None:
        nonlocal current, current_hash
        after = Winding(tuple(left + right for left, right in zip(current, delta)))
        next_hash = (
            _demo_state_hash(chain_id, len(records) + 1, after)
            if accepted
            else current_hash
        )
        records.append(
            TransitionRecord(
                chain_id=chain_id,
                sweep=len(records),
                proposal_id=f"demo-{len(records):04d}",
                proposal_type=proposal_type,
                axis=axis,
                orientation=orientation,
                accepted=accepted,
                w_before=current,
                w_after=after,
                q_before=sector_from_winding(current, divergence_free=True),
                q_after=sector_from_winding(after, divergence_free=True),
                source_state_hash_before=current_hash,
                source_state_hash_after=next_hash,
            )
        )
        current = after
        current_hash = next_hash

    append(ProposalType.CUBE, (0, 0, 0))
    append(ProposalType.SECTOR_MOVE, (1, 0, 0), axis=Axis.X, orientation=1)
    append(ProposalType.SECTOR_MOVE, (0, 1, 0), axis=Axis.Y, orientation=1)
    append(ProposalType.EVEN_CURRENT_WORM, (2, 0, 0))
    append(ProposalType.SECTOR_MOVE, (-1, 0, 0), axis=Axis.X, orientation=-1)
    append(ProposalType.SECTOR_MOVE, (0, 0, 1), axis=Axis.Z, orientation=1)
    append(ProposalType.SECTOR_MOVE, (1, 0, 0), axis=Axis.X, orientation=1)
    append(ProposalType.SECTOR_MOVE, (0, -1, 0), axis=Axis.Y, orientation=-1)
    append(ProposalType.SECTOR_MOVE, (-1, 0, 0), axis=Axis.X, orientation=-1)
    append(ProposalType.SECTOR_MOVE, (0, 0, -1), axis=Axis.Z, orientation=-1)
    append(
        ProposalType.SECTOR_MOVE,
        (0, 0, 0),
        axis=Axis.X,
        orientation=1,
        accepted=False,
    )
    return records


def demo_generators() -> list[GeneratorReceipt]:
    from .orbit import LiftabilityStatus

    return [
        GeneratorReceipt.axis(
            axis,
            liftability=LiftabilityStatus.EXHAUSTIVE_FINITE_CHECK,
            evidence_ref="deterministic demo fixture only",
        )
        for axis in Axis
    ]
