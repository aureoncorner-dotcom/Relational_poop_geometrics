from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any, Iterable

from .errors import DomainError

PHI_INVERSE_SQUARE = ((math.sqrt(5.0) - 1.0) / 2.0) ** 2


def fractional_part(value: float) -> float:
    if not math.isfinite(value):
        raise DomainError("phase input must be finite")
    return value % 1.0


def circle_distance(left: float, right: float) -> float:
    delta = abs(fractional_part(left) - fractional_part(right))
    return min(delta, 1.0 - delta)


@dataclass(frozen=True, slots=True)
class MessageReset:
    reset_id: str
    effective_index: int
    theta_after: float
    reason: str

    def __post_init__(self) -> None:
        if not self.reset_id.strip() or not self.reason.strip():
            raise DomainError("message reset_id and reason must be non-empty")
        if (
            not isinstance(self.effective_index, int)
            or isinstance(self.effective_index, bool)
            or self.effective_index < 0
        ):
            raise DomainError("message reset effective_index must be non-negative")
        if not 0 <= self.theta_after < 1 or not math.isfinite(self.theta_after):
            raise DomainError("theta_after must be a finite phase in [0,1)")


@dataclass(frozen=True, slots=True)
class LatticeReset:
    reset_id: str
    timestamp: float
    g_after: float
    reason: str

    def __post_init__(self) -> None:
        if not self.reset_id.strip() or not self.reason.strip():
            raise DomainError("lattice reset_id and reason must be non-empty")
        if not math.isfinite(self.timestamp):
            raise DomainError("lattice reset timestamp must be finite")
        if not 0 <= self.g_after < 1 or not math.isfinite(self.g_after):
            raise DomainError("g_after must be a finite phase in [0,1)")


@dataclass(frozen=True, slots=True)
class TwoClockConfig:
    theta0: float
    lattice_period: float
    g0: float
    lattice_order: int
    catch_width: float
    timestamp_units: str
    time_origin: float = 0.0
    alpha: float = PHI_INVERSE_SQUARE
    boundary_tolerance: float = 1e-12
    message_resets: tuple[MessageReset, ...] = ()
    lattice_resets: tuple[LatticeReset, ...] = ()
    sites_labelled: bool = False
    labelled_reference_site_id: str | None = None
    phase_anchor_id: str | None = None
    lag_convention: str = "evaluate lattice phase at opportunity timestamp"
    eligibility_ledger_id: str | None = None
    outcome_codebook_id: str | None = None
    training_holdout_plan: str | None = None
    multiplicity_rule: str | None = None

    def __post_init__(self) -> None:
        for value, label in ((self.theta0, "theta0"), (self.g0, "g0")):
            if not math.isfinite(value) or not 0 <= value < 1:
                raise DomainError(f"{label} must be a finite phase in [0,1)")
        if not math.isfinite(self.alpha) or self.alpha <= 0:
            raise DomainError("alpha must be finite and positive")
        if not math.isfinite(self.lattice_period) or self.lattice_period <= 0:
            raise DomainError("lattice_period must be finite and positive")
        if (
            not isinstance(self.lattice_order, int)
            or isinstance(self.lattice_order, bool)
            or self.lattice_order <= 0
        ):
            raise DomainError("lattice_order q must be a positive integer")
        max_width = 1.0 / (2.0 * self.lattice_order)
        if not math.isfinite(self.catch_width) or not 0 <= self.catch_width < max_width:
            raise DomainError("catch_width must satisfy 0 <= w < 1/(2q)")
        if (
            not math.isfinite(self.boundary_tolerance)
            or self.boundary_tolerance < 0
            or self.boundary_tolerance >= max_width
        ):
            raise DomainError("boundary_tolerance must be non-negative and smaller than 1/(2q)")
        if not isinstance(self.timestamp_units, str) or not self.timestamp_units.strip():
            raise DomainError("timestamp_units must be explicit")
        if not math.isfinite(self.time_origin):
            raise DomainError("time_origin must be finite")
        if not isinstance(self.sites_labelled, bool):
            raise DomainError("sites_labelled must be boolean")
        if self.sites_labelled and not self.labelled_reference_site_id:
            raise DomainError("labelled sites require labelled_reference_site_id")
        if not self.sites_labelled and self.labelled_reference_site_id is not None:
            raise DomainError("an unlabelled lattice cannot name a reference site")

        message_indices = [reset.effective_index for reset in self.message_resets]
        lattice_times = [reset.timestamp for reset in self.lattice_resets]
        if message_indices != sorted(message_indices) or len(message_indices) != len(set(message_indices)):
            raise DomainError("message resets must be strictly ordered by unique effective_index")
        if lattice_times != sorted(lattice_times) or len(lattice_times) != len(set(lattice_times)):
            raise DomainError("lattice resets must be strictly ordered by unique timestamp")
        if any(timestamp < self.time_origin for timestamp in lattice_times):
            raise DomainError("lattice resets cannot precede time_origin")

    @property
    def unlabelled_configuration_period(self) -> float:
        return self.lattice_period / self.lattice_order

    @property
    def labelled_reference_period(self) -> float | None:
        return self.lattice_period if self.sites_labelled else None

    def message_phase(self, index: int) -> float:
        if not isinstance(index, int) or isinstance(index, bool) or index < 0:
            raise DomainError("message index must be a non-negative integer")
        base_index = 0
        base_phase = self.theta0
        for reset in self.message_resets:
            if reset.effective_index > index:
                break
            base_index = reset.effective_index
            base_phase = reset.theta_after
        return fractional_part(base_phase + (index - base_index) * self.alpha)

    def lattice_phase(self, timestamp: float) -> float:
        if not math.isfinite(timestamp):
            raise DomainError("timestamp must be finite")
        if timestamp < self.time_origin:
            raise DomainError("timestamp precedes the declared time_origin")
        base_time = self.time_origin
        base_phase = self.g0
        for reset in self.lattice_resets:
            if reset.timestamp > timestamp:
                break
            base_time = reset.timestamp
            base_phase = reset.g_after
        return fractional_part(base_phase - (timestamp - base_time) / self.lattice_period)

    def catch_distance(self, index: int, timestamp: float) -> float:
        theta = self.message_phase(index)
        lattice = self.lattice_phase(timestamp)
        return min(
            circle_distance(theta, lattice + site / self.lattice_order)
            for site in range(self.lattice_order)
        )

    def classify(
        self, index: int, timestamp: float, *, eligible: bool | None
    ) -> dict[str, Any]:
        if eligible is False:
            return {
                "index": index,
                "timestamp": timestamp,
                "prediction": "INELIGIBLE",
                "catch_distance": None,
                "boundary_tolerance": self.boundary_tolerance,
            }
        if eligible is None:
            return {
                "index": index,
                "timestamp": timestamp,
                "prediction": "UNRESOLVED",
                "catch_distance": None,
                "boundary_tolerance": self.boundary_tolerance,
                "reason": "eligibility is unknown",
            }
        if eligible is not True:
            raise DomainError("eligible must be true, false, or null")
        distance = self.catch_distance(index, timestamp)
        if abs(distance - self.catch_width) <= self.boundary_tolerance:
            prediction = "UNRESOLVED"
            reason = "distance lies within the frozen classifier boundary tolerance"
        elif distance < self.catch_width:
            prediction = "CATCH"
            reason = None
        else:
            prediction = "MISS"
            reason = None
        result = {
            "index": index,
            "timestamp": timestamp,
            "message_phase": self.message_phase(index),
            "lattice_phase": self.lattice_phase(timestamp),
            "catch_distance": distance,
            "catch_width": self.catch_width,
            "boundary_tolerance": self.boundary_tolerance,
            "prediction": prediction,
        }
        if reason is not None:
            result["reason"] = reason
        return result

    def verify_unlabelled_period(self, index: int, timestamp: float) -> bool:
        first = self.catch_distance(index, timestamp)
        second = self.catch_distance(index, timestamp + self.unlabelled_configuration_period)
        return math.isclose(first, second, rel_tol=0.0, abs_tol=max(self.boundary_tolerance, 1e-14))

    def to_spec(self) -> dict[str, Any]:
        return {
            "spec_version": "0.2-audit-repaired",
            "status": "PROSPECTIVE_FORMAL_ONLY",
            "numeric_policy": {
                "arithmetic": "IEEE-754 binary64",
                "phase_range": "canonical fractional part in [0,1)",
                "alpha_expression": "phi^-2",
                "alpha_value": self.alpha,
                "classification_boundary_tolerance": self.boundary_tolerance,
                "rounding_rule": "do not round before distance comparison",
            },
            "message_clock": {
                "phase_rule": "theta(n)=frac(theta_after+(n-reset_index)*alpha)",
                "alpha": self.alpha,
                "theta_0": self.theta0,
                "reset_ledger": [
                    {
                        "reset_id": reset.reset_id,
                        "effective_index": reset.effective_index,
                        "theta_after": reset.theta_after,
                        "reason": reset.reason,
                    }
                    for reset in self.message_resets
                ],
            },
            "lattice_clock": {
                "phase_rule": "g(t)=frac(g_after-(t-reset_timestamp)/T_g)",
                "direction": "clockwise",
                "T_g": self.lattice_period,
                "g_0": self.g0,
                "time_origin": self.time_origin,
                "timestamp_units": self.timestamp_units,
                "reset_ledger": [
                    {
                        "reset_id": reset.reset_id,
                        "timestamp": reset.timestamp,
                        "g_after": reset.g_after,
                        "reason": reset.reason,
                    }
                    for reset in self.lattice_resets
                ],
                "lattice_order_q": self.lattice_order,
                "sites_labelled": self.sites_labelled,
                "unlabelled_configuration_period": self.unlabelled_configuration_period,
                "labelled_reference_period": self.labelled_reference_period,
                "labelled_reference_site_id": self.labelled_reference_site_id,
                "phase_anchor_id": self.phase_anchor_id,
            },
            "opportunities": {
                "timestamp_source": self.timestamp_units,
                "eligibility_ledger_id": self.eligibility_ledger_id,
                "lag_convention": self.lag_convention,
                "catch_width_w": self.catch_width,
                "catch_width_constraint": "0 <= w < 1/(2q)",
                "site_index_range": f"0 <= k < {self.lattice_order}",
                "catch_distance": "min_{0<=k<q} d_circle(theta_n,g(t_n)+k/q)",
                "classifier": "CATCH iff distance < w outside boundary tolerance",
                "boundary_tolerance": self.boundary_tolerance,
                "prediction_codes": ["CATCH", "MISS", "INELIGIBLE", "UNRESOLVED"],
                "outcome_codebook_id": self.outcome_codebook_id,
            },
            "analysis": {
                "parameter_search_allowed": False,
                "training_holdout_plan": self.training_holdout_plan,
                "multiplicity_rule": self.multiplicity_rule,
                "prospective_test_status": "NOT_RUN",
            },
            "evidence_boundary": {
                "platform_instantiation": "UNRESOLVED",
                "moving_lattice_established": False,
                "old_null_overridden": False,
                "catch_is_outcome": False,
            },
        }


def classify_opportunities(
    config: TwoClockConfig, opportunities: Iterable[tuple[int, float, bool | None]]
) -> list[dict[str, Any]]:
    return [
        config.classify(index, timestamp, eligible=eligible)
        for index, timestamp, eligible in opportunities
    ]
