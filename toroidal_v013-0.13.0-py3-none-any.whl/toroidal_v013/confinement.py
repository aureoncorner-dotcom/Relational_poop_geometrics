from __future__ import annotations

import math
from dataclasses import dataclass
from enum import Enum
from typing import Any

from .errors import DomainError


class ModelPreference(str, Enum):
    FINITE_RANGE = "FINITE_RANGE_PREFERRED"
    LONG_RANGE = "LONG_RANGE_PREFERRED"
    AMBIGUOUS = "MODEL_AMBIGUOUS"


class FitValidity(str, Enum):
    VALID = "VALID"
    INVALID = "INVALID"
    UNRESOLVED = "UNRESOLVED"


class EstimatorConcordance(str, Enum):
    CONCORDANT = "CONCORDANT"
    DISCORDANT = "DISCORDANT"
    MISSING = "DIAGNOSTICS_MISSING"
    NOT_APPLICABLE = "NOT_APPLICABLE"


@dataclass(frozen=True, slots=True)
class ConfinementAssessment:
    model_preference: ModelPreference
    fit_validity: FitValidity
    estimator_concordance: EstimatorConcordance
    l_max: int
    xi_conf_primary: float | None = None
    xi_conf_95_ucb: float | None = None
    diagnostic_estimates: tuple[float, ...] = ()
    independent_long_range_criteria_preregistered: bool = False
    independent_long_range_criteria_passed: bool | None = None

    def __post_init__(self) -> None:
        for field_name, enum_type in (
            ("model_preference", ModelPreference),
            ("fit_validity", FitValidity),
            ("estimator_concordance", EstimatorConcordance),
        ):
            value = getattr(self, field_name)
            if not isinstance(value, enum_type):
                object.__setattr__(self, field_name, enum_type(value))
        if not isinstance(self.l_max, int) or isinstance(self.l_max, bool) or self.l_max <= 0:
            raise DomainError("l_max must be a positive integer")
        for value, label in (
            (self.xi_conf_primary, "xi_conf_primary"),
            (self.xi_conf_95_ucb, "xi_conf_95_ucb"),
        ):
            if value is not None and (not math.isfinite(value) or value <= 0):
                raise DomainError(f"{label} must be null or finite and positive")
        if any(not math.isfinite(value) or value <= 0 for value in self.diagnostic_estimates):
            raise DomainError("diagnostic estimates must be finite and positive")
        if not isinstance(self.independent_long_range_criteria_preregistered, bool):
            raise DomainError("long-range preregistration flag must be boolean")
        if self.independent_long_range_criteria_passed not in (True, False, None):
            raise DomainError("long-range criteria result must be true, false, or null")

    def evaluate(self) -> dict[str, Any]:
        gate = "UNRESOLVED"
        admissibility = "UNRESOLVED"
        label: str

        if self.fit_validity is FitValidity.INVALID:
            gate = "INVALID"
            admissibility = "INVALID"
            label = "Q2 INCONCLUSIVE — CONFINEMENT-SCALE ESTIMATOR INVALID"
        elif self.fit_validity is FitValidity.UNRESOLVED:
            label = "Q2 UNRESOLVED — CONFINEMENT-SCALE FIT NOT RESOLVED"
        elif self.model_preference is ModelPreference.AMBIGUOUS:
            label = "Q2 UNRESOLVED — FINITE-RANGE AND LONG-RANGE DESCRIPTIONS NOT DISTINGUISHED"
        elif self.model_preference is ModelPreference.LONG_RANGE:
            gate = "INAPPLICABLE"
            if self.xi_conf_primary is not None or self.xi_conf_95_ucb is not None:
                raise DomainError("long-range preference requires finite xi fields to remain null")
            if self.estimator_concordance is not EstimatorConcordance.NOT_APPLICABLE:
                raise DomainError("estimator concordance must be NOT_APPLICABLE for long-range branch")
            if (
                self.independent_long_range_criteria_preregistered
                and self.independent_long_range_criteria_passed is True
            ):
                admissibility = "ADMISSIBLE"
                label = "LONG-RANGE BRANCH ADMISSIBLE BY PREREGISTERED INDEPENDENT CRITERIA"
            else:
                label = (
                    "Q2 UNRESOLVED — LONG-RANGE MODEL PREFERRED, "
                    "ASYMPTOTIC VERDICT NOT PREREGISTERED OR NOT PASSED"
                )
        else:
            if self.estimator_concordance is EstimatorConcordance.MISSING:
                label = "Q2 UNRESOLVED — CONFINEMENT-SCALE DIAGNOSTICS MISSING"
            elif self.estimator_concordance is EstimatorConcordance.DISCORDANT:
                label = "Q2 UNRESOLVED — CONFINEMENT-SCALE ESTIMATORS DISCORDANT"
            elif self.estimator_concordance is EstimatorConcordance.NOT_APPLICABLE:
                raise DomainError("finite-range branch requires an estimator-concordance result")
            elif self.xi_conf_primary is None or self.xi_conf_95_ucb is None:
                gate = "INVALID"
                admissibility = "INVALID"
                label = "Q2 INCONCLUSIVE — FINITE-RANGE ESTIMATE OR UCB MISSING"
            elif len(self.diagnostic_estimates) < 2:
                label = "Q2 UNRESOLVED — FEWER THAN TWO PREREGISTERED DIAGNOSTICS"
            elif self.l_max >= 4.0 * self.xi_conf_95_ucb:
                gate = "CLEARED"
                admissibility = "ADMISSIBLE"
                label = "Q2 SCALE-ADMISSIBLE — REMAINING CANONICAL DIAGNOSTICS STILL REQUIRED"
            else:
                gate = "NOT_CLEARED"
                admissibility = "INCONCLUSIVE"
                label = "Q2 INCONCLUSIVE — SCALE GATE NOT CLEARED"

        return {
            "schema_version": "0.2-audit-repaired",
            "model_preference": self.model_preference.value,
            "fit_validity": self.fit_validity.value,
            "estimator_concordance": self.estimator_concordance.value,
            "xi_conf_primary": self.xi_conf_primary,
            "xi_conf_95_ucb": self.xi_conf_95_ucb,
            "diagnostic_estimates": list(self.diagnostic_estimates),
            "l_max": self.l_max,
            "four_xi_gate": gate,
            "q2_scale_admissibility": admissibility,
            "independent_long_range_criteria_preregistered": (
                self.independent_long_range_criteria_preregistered
            ),
            "independent_long_range_criteria_passed": (
                self.independent_long_range_criteria_passed
            ),
            "required_label": label,
            "claim_boundary": (
                "Scale admissibility, model preference, estimator validity/concordance, formal "
                "orbit, observed accessibility, and mixing are separate coordinates."
            ),
        }
