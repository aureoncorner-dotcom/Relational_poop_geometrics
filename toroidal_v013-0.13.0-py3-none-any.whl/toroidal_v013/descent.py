from __future__ import annotations

from collections import defaultdict
from fractions import Fraction
from itertools import combinations
from typing import Any, Hashable, Mapping

from .errors import DomainError


def _probability(value: Any) -> Fraction:
    if isinstance(value, bool):
        raise DomainError("probabilities cannot be booleans")
    try:
        result = value if isinstance(value, Fraction) else Fraction(str(value))
    except (TypeError, ValueError, ZeroDivisionError) as error:
        raise DomainError(f"invalid probability {value!r}") from error
    if result < 0:
        raise DomainError("probabilities must be non-negative")
    return result


def strong_lumpability_report(
    kernel: Mapping[Hashable, Mapping[Hashable, Any]],
    projection: Mapping[Hashable, Hashable],
    *,
    tolerance: float = 1e-12,
) -> dict[str, Any]:
    """Test strong lumpability of a complete finite Markov kernel.

    Strong lumpability closes the projection for every initial full-state law.
    This routine does not claim that weaker stationary-law lumpability failed.
    """

    if tolerance < 0:
        raise DomainError("tolerance must be non-negative")
    states = tuple(kernel)
    if not states:
        return {
            "q_only_markov_closure": "UNRESOLVED",
            "strong_lumpability": "UNRESOLVED",
            "reason": "empty kernel",
            "counterexamples": [],
        }
    if set(projection) != set(states):
        raise DomainError("projection must cover exactly the kernel source states")
    state_set = set(states)
    tolerance_fraction = Fraction(str(tolerance))
    normalized: dict[Hashable, dict[Hashable, Fraction]] = {}
    for source, row in kernel.items():
        if not set(row).issubset(state_set):
            raise DomainError(f"kernel row {source!r} targets an unknown state")
        normalized_row = {target: _probability(value) for target, value in row.items()}
        total = sum(normalized_row.values(), Fraction(0))
        if abs(total - 1) > tolerance_fraction:
            raise DomainError(f"kernel row {source!r} sums to {float(total)}, not 1")
        normalized[source] = normalized_row

    blocks: dict[Hashable, list[Hashable]] = defaultdict(list)
    for state, label in projection.items():
        blocks[label].append(state)
    block_labels = tuple(blocks)

    def aggregate(source: Hashable) -> dict[Hashable, Fraction]:
        row = normalized[source]
        return {
            block: sum((row.get(target, Fraction(0)) for target in targets), Fraction(0))
            for block, targets in blocks.items()
        }

    aggregates = {state: aggregate(state) for state in states}
    counterexamples: list[dict[str, Any]] = []
    for source_block, members in blocks.items():
        for left, right in combinations(members, 2):
            differences = {
                str(target_block): {
                    "left": float(aggregates[left][target_block]),
                    "right": float(aggregates[right][target_block]),
                    "absolute_difference": float(
                        abs(aggregates[left][target_block] - aggregates[right][target_block])
                    ),
                }
                for target_block in block_labels
                if abs(aggregates[left][target_block] - aggregates[right][target_block])
                > tolerance_fraction
            }
            if differences:
                counterexamples.append(
                    {
                        "source_block": str(source_block),
                        "left_full_state": str(left),
                        "right_full_state": str(right),
                        "target_block_differences": differences,
                    }
                )

    closed = not counterexamples
    return {
        "q_only_markov_closure": "CLOSED" if closed else "FAILED",
        "strong_lumpability": "PASSED" if closed else "FAILED",
        "full_state_count": len(states),
        "projected_block_count": len(blocks),
        "tolerance": tolerance,
        "counterexamples": counterexamples,
        "claim_boundary": (
            "This is strong lumpability for the declared complete finite kernel. A failure does "
            "not rule out weak lumpability for a separately specified stationary law."
        ),
    }


def deterministic_residual_descent_report(
    next_state: Mapping[Hashable, Hashable],
    residual: Mapping[Hashable, Hashable],
) -> dict[str, Any]:
    """Test whether a deterministic full-state map descends through a residual."""

    if set(next_state) != set(residual):
        raise DomainError("next_state and residual must cover the same source states")
    states = set(next_state)
    if not states:
        return {
            "residual_closure": "UNRESOLVED",
            "reason": "empty declared domain",
            "counterexamples": [],
        }
    if not set(next_state.values()).issubset(states):
        raise DomainError("next_state maps outside the declared domain")
    groups: dict[Hashable, list[Hashable]] = defaultdict(list)
    for state, value in residual.items():
        groups[value].append(state)
    counterexamples: list[dict[str, Any]] = []
    for present_residual, members in groups.items():
        for left, right in combinations(members, 2):
            left_next = residual[next_state[left]]
            right_next = residual[next_state[right]]
            if left_next != right_next:
                counterexamples.append(
                    {
                        "present_residual": str(present_residual),
                        "left_full_state": str(left),
                        "right_full_state": str(right),
                        "left_next_residual": str(left_next),
                        "right_next_residual": str(right_next),
                    }
                )
    return {
        "residual_closure": "CLOSED" if not counterexamples else "FAILED",
        "domain_state_count": len(states),
        "residual_state_count": len(groups),
        "counterexamples": counterexamples,
    }


def not_claimed_projection_report() -> dict[str, Any]:
    return {
        "q_only_markov_closure": "NOT_CLAIMED",
        "strong_lumpability": "NOT_RUN",
        "counterexamples": [],
        "claim_boundary": (
            "q is retained as an exact observable and mixing diagnostic; no autonomous q-only "
            "dynamics is claimed without a complete finite-kernel test or proof."
        ),
    }
