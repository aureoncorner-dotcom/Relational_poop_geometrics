from __future__ import annotations

import math
from dataclasses import dataclass
from enum import Enum
from typing import Any

from .errors import DomainError


class ChartType(str, Enum):
    MATERIAL = "material"
    EULERIAN = "eulerian"


class GeometryModel(str, Enum):
    STRAIGHT_CYLINDER = "straight_cylinder"
    SLENDER_TORUS_APPROXIMATION = "slender_torus_approximation"


@dataclass(frozen=True, slots=True)
class ThroatProfile:
    length_steps: int
    u0: float
    epsilon: float
    s0: float
    material_radius0: float
    eulerian_radius: float
    geometry: GeometryModel = GeometryModel.STRAIGHT_CYLINDER
    tube_to_curvature_ratio: float | None = None

    def __post_init__(self) -> None:
        if (
            not isinstance(self.length_steps, int)
            or isinstance(self.length_steps, bool)
            or self.length_steps <= 1
        ):
            raise DomainError("length_steps must be an integer greater than one")
        if not math.isfinite(self.u0) or self.u0 <= 0:
            raise DomainError("u0 must be finite and positive")
        if not math.isfinite(self.epsilon) or not 0 <= self.epsilon < 1:
            raise DomainError("epsilon must satisfy 0 <= epsilon < 1")
        if not math.isfinite(self.s0):
            raise DomainError("s0 must be finite")
        if self.material_radius0 <= 0 or self.eulerian_radius <= 0:
            raise DomainError("tube radii must be positive")
        if not isinstance(self.geometry, GeometryModel):
            object.__setattr__(self, "geometry", GeometryModel(self.geometry))
        if self.geometry is GeometryModel.SLENDER_TORUS_APPROXIMATION:
            if (
                self.tube_to_curvature_ratio is None
                or not math.isfinite(self.tube_to_curvature_ratio)
                or not 0 < self.tube_to_curvature_ratio < 1
            ):
                raise DomainError(
                    "slender-torus mode requires 0 < tube_to_curvature_ratio < 1"
                )

    @property
    def L(self) -> float:
        return float(self.length_steps)

    def speed(self, s: float) -> float:
        return self.u0 * (
            1.0 + self.epsilon * math.cos(2.0 * math.pi * (s - self.s0) / self.L)
        )

    def speed_derivative(self, s: float) -> float:
        return (
            -self.u0
            * self.epsilon
            * (2.0 * math.pi / self.L)
            * math.sin(2.0 * math.pi * (s - self.s0) / self.L)
        )

    def radial_velocity(self, r: float, s: float) -> float:
        return -0.5 * r * self.speed_derivative(s)

    def material_radius(self, s: float) -> float:
        return self.material_radius0 * math.sqrt(self.u0 / self.speed(s))

    def material_flux(self, s: float) -> float:
        return math.pi * self.material_radius(s) ** 2 * self.speed(s)

    def eulerian_flux(self, s: float) -> float:
        return math.pi * self.eulerian_radius**2 * self.speed(s)

    def eulerian_increment(self, start: float, end: float) -> float:
        return self.eulerian_flux(end) - self.eulerian_flux(start)

    def eulerian_side_flux(self, start: float, end: float) -> float:
        return -self.eulerian_increment(start, end)


_OBSERVABLE_CHART = {
    "material_radius": ChartType.MATERIAL,
    "material_throughflow": ChartType.MATERIAL,
    "relative_side_flux": ChartType.MATERIAL,
    "sectional_flux_peak": ChartType.EULERIAN,
    "fixed_boundary_side_flux": ChartType.EULERIAN,
    "spatial_flux_cocycle": ChartType.EULERIAN,
}


def require_typed_observable(chart: ChartType, observable: str) -> None:
    if not isinstance(chart, ChartType):
        chart = ChartType(chart)
    required = _OBSERVABLE_CHART.get(observable)
    if required is None:
        raise DomainError(f"unknown TTSC observable {observable!r}")
    if chart is not required:
        raise DomainError(
            f"observable {observable!r} belongs to the {required.value} chart, not {chart.value}"
        )


def spatial_flux_report(profile: ThroatProfile, *, tolerance: float = 1e-12) -> dict[str, Any]:
    if tolerance < 0:
        raise DomainError("tolerance must be non-negative")
    q_euler = [profile.eulerian_flux(step) for step in range(profile.length_steps + 1)]
    increments = [right - left for left, right in zip(q_euler, q_euler[1:])]
    side_flux = [-value for value in increments]
    local_residuals = [
        (right - left) + side
        for left, right, side in zip(q_euler, q_euler[1:], side_flux)
    ]
    loop_cocycle = sum(increments)
    q_material = [profile.material_flux(step) for step in range(profile.length_steps + 1)]
    material_reference = math.pi * profile.material_radius0**2 * profile.u0
    material_residuals = [value - material_reference for value in q_material]
    tangency_residuals = []
    for step in range(profile.length_steps + 1):
        radius = profile.material_radius(step)
        radius_derivative = (
            -0.5 * radius * profile.speed_derivative(step) / profile.speed(step)
        )
        tangency_residuals.append(
            profile.speed(step) * radius_derivative
            - profile.radial_velocity(radius, step)
        )
    periodic_ok = abs(loop_cocycle) <= tolerance
    local_ok = all(abs(value) <= tolerance for value in local_residuals)
    material_ok = all(abs(value) <= tolerance for value in material_residuals) and all(
        abs(value) <= tolerance for value in tangency_residuals
    )
    return {
        "ttsc_version": "0.3-audit-repaired",
        "geometry_model": profile.geometry.value,
        "tube_to_curvature_ratio": profile.tube_to_curvature_ratio,
        "material": {
            "throughflow": q_material,
            "throughflow_constancy_residuals": material_residuals,
            "boundary_tangency_residuals": tangency_residuals,
            "relative_side_flux_residuals": [0.0] * profile.length_steps,
            "zero_cocycle": [0.0] * profile.length_steps,
            "checks_passed": material_ok,
        },
        "eulerian": {
            "sectional_flux_profile": q_euler,
            "side_flux_profile": side_flux,
            "local_conservation_residuals": local_residuals,
            "spatial_cocycle_increments": increments,
            "accumulated_loop_cocycle": loop_cocycle,
            "periodic_flux_closure": periodic_ok,
            "local_conservation": local_ok,
        },
        "residual_dynamics": {
            "claimed": False,
            "descent_status": "NOT_APPLICABLE_SPATIAL_COMPARATOR",
        },
        "claim_boundary": (
            "The field is exact in the straight cylindrical chart. Slender-torus mode is an "
            "explicit approximation flag, not an implicit curvature correction. Periodic flux "
            "closure is not autonomous residual closure."
        ),
    }
